# Template
this is a template for student to make their EDR into a server
